const path = require('path')

function resolve(dir) {
  // return path.join(__dirname, '..', dir)
  return path.join(__dirname, dir)
}

// vue.config.js
module.exports = {
  configureWebpack: {
    // 配置解决默认使用vue.runTime.esm打开报错的文件，设置使用vue.esm.js打开
    resolve: {
      extensions: ['.js', '.vue', '.json'],
      alias: {
        'vue$': 'vue/dist/vue.esm.js',
        '@': resolve('src'),
      }
    },
    // 配置解决跨域配置文件
    devServer: {
      proxy: {
        '/api': {
          target: 'http://localhost:5000', // 目录地址
          changeOrigin: true, //是否跨域，
          pathRewrite: { // 重写路径: 去掉路径中开头的'/api'
            '^/api': ''
          }
        },
      }
    }
  }
}