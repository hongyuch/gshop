<template>
  <div>
    <router-view></router-view>
    <FooterGuide v-show="$route.meta.isShowFooter"/>
  </div>
</template>

<script>
import FooterGuide from './components/FooterGuide/FooterGuide'

// import { reqPlice } from './api'

  export default {
    components:{
      FooterGuide
    },
    // 测试接口
    // async mounted() {
    //   const result = await reqPlice(40.10038,116.36867)
    //   console.log(result.data)
    // },
  }
</script>

<style lang="stylus" rel="stylesheet/stylus" scoped>
  
</style>
