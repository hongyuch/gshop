// 保存状态数据
export default {
  // 经度
  longitude: '116.36867',
  // 纬度
  latitude: '40.10038',
  // 地理位置(地址)
  address: '正在获取中...',
  // 商品分类信息数组
  category: [],
  // 商家列表数组
  shops: []
}