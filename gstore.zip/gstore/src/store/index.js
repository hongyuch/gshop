// 引入vue
import Vue from 'vue'
// 引入vuex
import Vuex from 'vuex'
// 引入管理模块
import state from './state'
import mutations from './mutations'
import actions from './actions'
import getter from './getter'

Vue.use(Vuex)
// 暴露store对象
export default new Vuex.Store({
  state,
  mutations,
  actions,
  getter
})