// 保存操作状态数据的计算属性的getter方法
export default {

}