// 保存间接操作状态数据的方法
export default {

}