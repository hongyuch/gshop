// 保存直接操作状态数据的方法

// 引入mutation的常量
import {} from './mutation-types'

export default {
  // 直接修改state中的地理位置(地址)

}