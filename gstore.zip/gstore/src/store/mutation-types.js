// 保存mutation的常量名

// 修改地址信息
export const REVISION_ADDRESS = 'revision_address'

// 修改商品分类
